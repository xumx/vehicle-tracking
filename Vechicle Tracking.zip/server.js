require("coffee-script");
require("./app");